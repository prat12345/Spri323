package com.pratyush.spring.dao;

/**
 * @author pratyush
 *
 */
public interface IdGeneratorDao {
	
	public int doIncrementWithLock() ;

}
